#ifndef BOARD_H_
#define BOARD_H_

#include <Arduino.h>

String getBoardName();

#endif
